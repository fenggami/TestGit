/**
 * @author fenggami
 * 功能：为了便于校验诉讼后台的利息计算以及逾期管理费等数据是否正确
 * @param overdueFees 基础逾期管理费
 * @param specialOverdueFees  特殊逾期管理费
 * @param overdueInterest  逾期罚息
 * @totalOverdueFees =overdueFees+specialOverdueFees 总逾期管理费
 */
import java.text.ParseException;
import java.util.*;
import java.text.SimpleDateFormat;
public class InterestCalculator {
    public static void main(String args[]) throws ParseException {
        InterestCalculatorTools tools = new InterestCalculatorTools();
        Scanner date = new Scanner(System.in);
        String lendOutDate = date.nextLine();
        String endDate = date.nextLine();
        Double principal = date.nextDouble();
        Double interestRate = date.nextDouble();
        //借款天数
        int lenddays = tools.daysBetween(lendOutDate,endDate)+1;
        Double interest = tools.Calculator(principal,interestRate,lenddays);
        System.out.println("利息为："+String.format("%.2f",interest-0.005));
        SimpleDateFormat sdf =  new SimpleDateFormat( "yyyy-MM-dd" );
        String today = sdf.format(new Date());
        int overduedays = tools.daysBetween(endDate,today)-1;
        Double overdueInterest =tools.OverdueFeeCalculator(principal,overduedays);
        System.out.println("逾期罚息："+String.format("%.2f",overdueInterest-0.005));
        System.out.println(overduedays);
    }

}