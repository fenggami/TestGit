/**
 * @author fenggami
 * 功能：为了便于校验诉讼后台的利息计算以及逾期管理费等数据是否正确
 */
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 * 功能：计算利息公式（注意：逾期时，借款天数t+1，需要加上宽限期）
 * @return interest 利息
 */
public class InterestCalculatorTools {
    public static double Calculator(double m, double i, int t) {
        double interest;
        if (m == 0) return 0.005;
        if (t <= 365) {
            interest = m * i * t / 36500 + m-m;
        } else {
            interest = m * Math.pow((i / 100 + 1), t / 365.0)-m;
        }
        return interest;
    }

    /**
     * @author fenggami
     * 功能：为了便于校验诉讼后台的利息计算以及逾期管理费等数据是否正确
     * @param overdueDays 逾期天数
     * @return  overdueFees 基础逾期管理费
     * @return  specialOverdueFees  特殊逾期管理费
     * @return  overdueInterest  逾期罚息
     * @totalOverdueFees =overdueFees+specialOverdueFees 总逾期管理费
     */
    public static double OverdueFeeCalculator(double m,int overdueDays){
        double overdueInterest;
        if (m == 0) return 0.005;
        overdueInterest = overdueDays*m*0.24/365;
        return overdueInterest;
    }

    /**
     * 字符串的日期格式的计算
     *
     * @param smdate 开始时间 格式："2016-08-22"
     * @param bdate  截止时间 格式："2016-08-22"
     * @return 相差天数
     */
    public static int daysBetween(String smdate, String bdate) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        cal.setTime(sdf.parse(smdate));
        long time1 = cal.getTimeInMillis();
        cal.setTime(sdf.parse(bdate));
        long time2 = cal.getTimeInMillis();
        long between_days = (time2 - time1) / (1000 * 3600 * 24);
        return Integer.parseInt(String.valueOf(between_days));
    }
}
